import { ArrowRight, Download , createLucideIcon } from "lucide-react";

// GitHub SVG Path from Simple Icons
const Github = createLucideIcon('Github', [
  ['path', { d: 'M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12' }]
]);

// LinkedIn SVG Path from Simple Icons
const Linkedin = createLucideIcon('Linkedin', [
  ['path', { d: 'M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z' }]
]);

function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden bg-slate-950 px-6 pt-24"
    >
      {/* Background glow */}
      <div className="absolute left-1/2 top-1/3 -z-0 h-96 w-96 -translate-x-1/2 rounded-full bg-blue-600/20 blur-3xl" />

      <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-2">

        {/* Content */}
        <div>
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.25em] text-blue-400">
            Senior Full Stack Web Developer
          </p>

          <h1 className="text-5xl font-bold leading-tight text-white sm:text-6xl lg:text-7xl">
            Hi, I'm{" "}
            <span className="text-blue-500">
              Bharat Bhokre
            </span>
          </h1>

          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-400">
            I build scalable web applications, SaaS platforms,
            fintech solutions, e-commerce experiences, and powerful
            business websites using modern web technologies.
          </p>

          {/* Buttons */}
          <div className="mt-8 flex flex-wrap gap-4">

            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-6 py-3 font-medium text-white transition hover:bg-blue-700"
            >
              View My Work
              <ArrowRight size={18} />
            </a>

            <a
              href="/resume.pdf"
              download
              className="inline-flex items-center gap-2 rounded-lg border border-white/20 px-6 py-3 font-medium text-white transition hover:bg-white/10"
            >
              Download Resume
              <Download size={18} />
            </a>

          </div>

          {/* Social */}
          <div className="mt-8 flex items-center gap-4">

            <a
              href="https://github.com/bhokrebharat5"
              className="rounded-lg border border-white/10 p-3 text-slate-400 transition hover:border-blue-500 hover:text-blue-500"
              aria-label="GitHub"
            >
              <Github className="w-5 h-5 stroke-[1.5]" />
            </a>

            <a
              href="http://www.linkedin.com/in/bharat-bhokre-a19a06345"
              className="rounded-lg border border-white/10 p-3 text-slate-400 transition hover:border-blue-500 hover:text-blue-500"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-5 h-5 stroke-[1.5]" />
            </a>

          </div>
        </div>

        {/* Right Side */}
        <div className="hidden lg:flex lg:justify-center">

          <div className="relative h-96 w-96">

            <div className="absolute inset-0 rounded-3xl border border-blue-500/20 bg-white/5 backdrop-blur-xl" />

            <div className="absolute inset-6 rounded-2xl border border-white/10 bg-slate-900 p-8">

              <div className="mb-6 flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-red-500" />
                <span className="h-3 w-3 rounded-full bg-yellow-500" />
                <span className="h-3 w-3 rounded-full bg-green-500" />
              </div>

              <div className="space-y-4 font-mono text-sm">
                <p className="text-slate-500">
                  {"// developer.js"}
                </p>

                <p>
                  <span className="text-purple-400">const</span>{" "}
                  <span className="text-blue-400">developer</span>{" "}
                  = {"{"}
                </p>

                <p className="pl-5">
                  name:{" "}
                  <span className="text-green-400">
                    "Bharat Bhokre"
                  </span>
                  ,
                </p>

                <p className="pl-5">
                  experience:{" "}
                  <span className="text-orange-400">
                    "10+ years"
                  </span>
                  ,
                </p>

                <p className="pl-5">
                  frontend:{" "}
                  <span className="text-green-400">
                    "React.js"
                  </span>
                  ,
                </p>

                <p className="pl-5">
                  backend:{" "}
                  <span className="text-green-400">
                    "Node.js"
                  </span>
                  ,
                </p>

                <p className="pl-5">
                  cms:{" "}
                  <span className="text-green-400">
                    "WordPress"
                  </span>
                  ,
                </p>

                <p className="pl-5">
                  projects:{" "}
                  <span className="text-orange-400">
                    "300+"
                  </span>
                </p>

                <p>{"}"}</p>
              </div>

            </div>
          </div>
        </div>

      </div>
    </section>
  );
}

export default Hero;