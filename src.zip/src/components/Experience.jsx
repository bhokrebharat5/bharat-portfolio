import { Briefcase, Calendar } from "lucide-react";

function Experience() {
  const experiences = [
    {
      company: "WDT Technologies Pvt Ltd",
      role: "Sr. Full Stack Web Developer",
      period: "Jan 2025 – Present",
      description:
        "Developing and optimizing a scalable AI agent management platform using React, TypeScript, Redux Toolkit and Vite.",
      points: [
        "Built a multi-tenant SPA with real-time Server-Sent Events (SSE) streaming.",
        "Worked on a visual DAG workflow editor.",
        "Improved application state management and performance.",
        "Developed WordPress and WooCommerce applications with custom plugins and REST APIs.",
      ],
    },
    {
      company: "Greychain Technology",
      role: "Sr. Full Stack Developer",
      period: "Aug 2022 – Dec 2024",
      description:
        "Led full-stack development of fintech platforms and high-performance mobile application backends.",
      points: [
        "Architected scalable RESTful APIs.",
        "Integrated secure third-party payment services.",
        "Managed a cross-functional development team.",
        "Conducted code reviews and managed Agile sprints.",
        "Delivered custom WordPress and WooCommerce solutions.",
      ],
    },
    {
      company: "Clickspurr Technologies",
      role: "Sr. React Js Developer",
      period: "May 2022 – Aug 2022",
      description:
        "Developed and deployed dynamic web applications using React.js and Node.js.",
      points: [
        "Built responsive frontend interfaces.",
        "Collaborated with design and product teams.",
        "Translated UI/UX designs into production-ready interfaces.",
      ],
    },
    {
      company: "Bitcot Technologies",
      role: "Software Engineer",
      period: "Dec 2015 – May 2022",
      description:
        "Worked across full-stack web development, Shopify applications and WordPress/WooCommerce solutions.",
      points: [
        "Developed and published 5 Shopify public applications.",
        "Built Shopify applications using Laravel and React.js.",
        "Developed custom WordPress plugins and themes.",
        "Integrated third-party APIs and e-commerce services.",
        "Handled system analysis, database design and full-stack development.",
      ],
    },
  ];

  return (
    <section
      id="experience"
      className="bg-slate-900 px-6 py-24"
    >
      <div className="mx-auto max-w-5xl">

        {/* Heading */}
        <div className="mb-16 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-blue-400">
            Career
          </p>

          <h2 className="mt-3 text-4xl font-bold text-white md:text-5xl">
            Professional Experience
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-slate-400">
            More than a decade of experience building web applications,
            e-commerce platforms and scalable digital products.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">

          {/* Timeline Line */}
          <div className="absolute left-4 top-0 hidden h-full w-px bg-white/10 md:block" />

          <div className="space-y-12">

            {experiences.map((experience, index) => (
              <div
                key={experience.company}
                className="relative md:pl-14"
              >

                {/* Timeline Icon */}
                <div className="absolute left-0 top-0 hidden h-9 w-9 items-center justify-center rounded-full border border-blue-500/30 bg-slate-950 text-blue-400 md:flex">
                  <Briefcase size={17} />
                </div>

                {/* Card */}
                <div className="rounded-2xl border border-white/10 bg-slate-950 p-7 transition hover:border-blue-500/30">

                  <div className="flex flex-col justify-between gap-4 md:flex-row">

                    <div>
                      <h3 className="text-xl font-bold text-white">
                        {experience.role}
                      </h3>

                      <p className="mt-1 font-medium text-blue-400">
                        {experience.company}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Calendar size={16} />
                      {experience.period}
                    </div>

                  </div>

                  <p className="mt-5 leading-7 text-slate-400">
                    {experience.description}
                  </p>

                  <ul className="mt-5 space-y-3">
                    {experience.points.map((point) => (
                      <li
                        key={point}
                        className="flex gap-3 text-sm leading-6 text-slate-400"
                      >
                        <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                        {point}
                      </li>
                    ))}
                  </ul>

                </div>
              </div>
            ))}

          </div>
        </div>
      </div>
    </section>
  );
}

export default Experience;