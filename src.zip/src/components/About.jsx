function About() {
  return (
    <section
      id="about"
      className="bg-slate-900 px-6 py-24"
    >
      <div className="mx-auto max-w-7xl">

        {/* Section Heading */}
        <div className="mb-12 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-blue-400">
            About Me
          </p>

          <h2 className="mt-3 text-4xl font-bold text-white md:text-5xl">
            Building Digital Experiences
          </h2>
        </div>

        <div className="grid gap-12 lg:grid-cols-2">

          {/* About Content */}
          <div>
            <h3 className="text-2xl font-semibold text-white">
              Senior Full Stack Web Developer
            </h3>

            <p className="mt-6 leading-8 text-slate-400">
              I am a Senior Full Stack Web Developer with 10+ years
              of hands-on experience building modern, scalable web
              applications and digital platforms.
            </p>

            <p className="mt-4 leading-8 text-slate-400">
              My experience spans React.js, TypeScript, Node.js,
              Laravel, CodeIgniter, WordPress, WooCommerce and
              Shopify application development.
            </p>

            <p className="mt-4 leading-8 text-slate-400">
              I have worked across e-commerce, healthcare, fintech
              and fitness domains, delivering scalable SPAs,
              RESTful APIs, CMS solutions and complex third-party
              integrations.
            </p>

            {/* Stats */}
            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3">

              <div className="rounded-xl border border-white/10 bg-slate-950 p-5">
                <h4 className="text-3xl font-bold text-blue-500">
                  10+
                </h4>
                <p className="mt-1 text-sm text-slate-400">
                  Years Experience
                </p>
              </div>

              <div className="rounded-xl border border-white/10 bg-slate-950 p-5">
                <h4 className="text-3xl font-bold text-blue-500">
                  300+
                </h4>
                <p className="mt-1 text-sm text-slate-400">
                  Projects
                </p>
              </div>

              <div className="rounded-xl border border-white/10 bg-slate-950 p-5">
                <h4 className="text-3xl font-bold text-blue-500">
                  5
                </h4>
                <p className="mt-1 text-sm text-slate-400">
                  Shopify Apps
                </p>
              </div>

            </div>
          </div>

          {/* What I Do */}
          <div className="rounded-2xl border border-white/10 bg-slate-950 p-8">

            <h3 className="text-2xl font-semibold text-white">
              What I Do
            </h3>

            <div className="mt-8 space-y-6">

              <div>
                <h4 className="font-semibold text-white">
                  Full Stack Development
                </h4>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  Scalable frontend applications and robust backend
                  APIs using modern technologies.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white">
                  E-commerce Development
                </h4>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  Custom WordPress, WooCommerce and Shopify solutions
                  with third-party integrations.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white">
                  API & Backend Architecture
                </h4>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  RESTful APIs, integrations, authentication and
                  scalable backend services.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white">
                  Application Performance
                </h4>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  State management, optimized applications and
                  performance-focused development.
                </p>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}

export default About;