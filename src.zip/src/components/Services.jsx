import {
  Code2,
  ShoppingCart,
  Globe,
  Server,
  Store,
  Zap,
} from "lucide-react";

function Services() {
  const services = [
    {
      icon: Code2,
      title: "Full Stack Development",
      description:
        "Build scalable and maintainable web applications using React.js, TypeScript, Node.js, Laravel and modern technologies.",
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Development",
      description:
        "Develop custom e-commerce solutions with WooCommerce, Shopify and payment gateway integrations.",
    },
    {
      icon: Globe,
      title: "WordPress Development",
      description:
        "Create custom WordPress websites, themes, plugins and WooCommerce solutions tailored to business requirements.",
    },
    {
      icon: Server,
      title: "API Development",
      description:
        "Design and develop robust RESTful APIs, backend services and third-party integrations.",
    },
    {
      icon: Store,
      title: "Shopify App Development",
      description:
        "Build custom Shopify applications and merchant-focused solutions using Laravel, React and JavaScript.",
    },
    {
      icon: Zap,
      title: "Performance Optimization",
      description:
        "Improve application performance, state management, API efficiency and overall user experience.",
    },
  ];

  return (
    <section
      id="services"
      className="bg-slate-900 px-6 py-24"
    >
      <div className="mx-auto max-w-7xl">

        <div className="mb-14 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-blue-400">
            Services
          </p>

          <h2 className="mt-3 text-4xl font-bold text-white md:text-5xl">
            How I Can Help
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-slate-400">
            From frontend development to backend architecture and
            e-commerce solutions, I help businesses build reliable
            digital products.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">

          {services.map((service) => {
            const Icon = service.icon;

            return (
              <div
                key={service.title}
                className="group rounded-2xl border border-white/10 bg-slate-950 p-7 transition duration-300 hover:-translate-y-1 hover:border-blue-500/40"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-blue-500/10 text-blue-400 transition group-hover:bg-blue-500 group-hover:text-white">
                  <Icon size={27} />
                </div>

                <h3 className="mt-6 text-xl font-semibold text-white">
                  {service.title}
                </h3>

                <p className="mt-4 text-sm leading-7 text-slate-400">
                  {service.description}
                </p>
              </div>
            );
          })}

        </div>
      </div>
    </section>
  );
}

export default Services;