import {
  ExternalLink,
  Sparkles,
  ShoppingCart,
  Cloud,
  HeartPulse,
  Utensils,
  BarChart3,
} from "lucide-react";

function Projects() {
  const projects = [
    {
      title: "MTX-Engines",
      category: "AI Agent Control Panel",
      icon: Sparkles,
      description:
        "A multi-tenant SPA for managing AI agents, tools, workflows and widgets with real-time SSE streaming and a DAG workflow editor.",
      technologies: [
        "React",
        "TypeScript",
        "Redux Toolkit",
        "RTK Query",
        "Vite",
        "Tailwind CSS",
        "Supabase",
      ],
      featured: true,
    },
    {
      title: "Fundly.ai",
      category: "Fintech Platform",
      icon: BarChart3,
      description:
        "Healthcare embedded fintech financing platform with financial transaction pages, payment scheduling modules and a multi-vendor admin console.",
      technologies: [
        "CodeIgniter",
        "MySQL",
        "React.js",
        "Node.js",
      ],
    },
    {
      title: "Space Jammit",
      category: "Cloud Storage App",
      icon: Cloud,
      description:
        "Secure cloud file storage platform featuring deep folder nesting, drag-and-drop operations and file manipulation capabilities.",
      technologies: [
        "React.js",
        "Node.js",
      ],
    },
    {
      title: "Oky",
      category: "Period Tracker App",
      icon: HeartPulse,
      description:
        "High-performance backend providing predictive cycle prediction REST APIs based on historical customer logs.",
      technologies: [
        "Node.js",
        "REST APIs",
      ],
    },
    {
      title: "Local Orbit",
      category: "Food Market App",
      icon: Utensils,
      description:
        "Food market platform with multi-role authentication and data verification processes for organization food market managers.",
      technologies: [
        "React.js",
        "Node.js",
      ],
    },
    {
      title: "Real Profit",
      category: "Shopify Application",
      icon: ShoppingCart,
      description:
        "Shopify analytics application calculating real-time net margins using shipping, payment fees and custom product costs.",
      technologies: [
        "Laravel",
        "MySQL",
        "React.js",
        "JavaScript",
      ],
    },
  ];

  return (
    <section
      id="projects"
      className="bg-slate-950 px-6 py-24"
    >
      <div className="mx-auto max-w-7xl">

        {/* Heading */}
        <div className="mb-14 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-blue-400">
            Portfolio
          </p>

          <h2 className="mt-3 text-4xl font-bold text-white md:text-5xl">
            Featured Projects
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-slate-400">
            A selection of applications and platforms I've built
            across AI, fintech, cloud storage, e-commerce and more.
          </p>
        </div>

        {/* Project Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">

          {projects.map((project) => {
            const Icon = project.icon;

            return (
              <article
                key={project.title}
                className={`group relative flex flex-col overflow-hidden rounded-2xl border bg-slate-900 p-7 transition duration-300 hover:-translate-y-1 ${
                  project.featured
                    ? "border-blue-500/40"
                    : "border-white/10 hover:border-blue-500/30"
                }`}
              >

                {/* Featured */}
                {project.featured && (
                  <span className="absolute right-5 top-5 rounded-full bg-blue-500/10 px-3 py-1 text-xs font-medium text-blue-400">
                    Featured
                  </span>
                )}

                {/* Icon */}
                <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-blue-500/10 text-blue-400">
                  <Icon size={27} />
                </div>

                <p className="mt-6 text-sm font-medium text-blue-400">
                  {project.category}
                </p>

                <h3 className="mt-2 text-2xl font-bold text-white">
                  {project.title}
                </h3>

                <p className="mt-4 flex-1 text-sm leading-7 text-slate-400">
                  {project.description}
                </p>

                {/* Technologies */}
                <div className="mt-6 flex flex-wrap gap-2">
                  {project.technologies.map((technology) => (
                    <span
                      key={technology}
                      className="rounded-md bg-slate-950 px-2.5 py-1 text-xs text-slate-400"
                    >
                      {technology}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="mt-7 flex gap-3 border-t border-white/10 pt-5">

                  <a
                    href="#"
                    className="flex items-center gap-2 text-sm text-slate-400 transition hover:text-white"
                  >
                    <ExternalLink size={16} />
                    Details
                  </a>

                  {/* <a
                    href="https://github.com/bhokrebharat5"
                    className="flex items-center gap-2 text-sm text-slate-400 transition hover:text-white"
                  >
                    <Github className="w-6 h-6 stroke-[1.5]" />
                  </a>  */}

                </div>

              </article>
            );
          })}

        </div>
      </div>
    </section>
  );
}

export default Projects;