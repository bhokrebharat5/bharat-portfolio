import {
  Code2,
  Server,
  Database,
  ShoppingBag,
  Cloud,
  GitBranch,
} from "lucide-react";

function Skills() {
  const skillGroups = [
    {
      icon: Code2,
      title: "Frontend",
      skills: [
        "React.js",
        "TypeScript",
        "Redux Toolkit",
        "RTK Query",
        "HTML5",
        "CSS3",
        "Tailwind CSS",
        "Bootstrap",
        "jQuery",
        "AJAX",
      ],
    },
    {
      icon: Server,
      title: "Backend",
      skills: [
        "Node.js",
        "Express.js",
        "Laravel",
        "CodeIgniter",
        "PHP",
        "REST APIs",
      ],
    },
    {
      icon: ShoppingBag,
      title: "CMS & E-commerce",
      skills: [
        "WordPress",
        "WooCommerce",
        "Shopify",
        "Shopify Liquid",
        "HubSpot",
      ],
    },
    {
      icon: Database,
      title: "Database",
      skills: [
        "MySQL",
        "Supabase",
        "Appwrite",
      ],
    },
    {
      icon: Cloud,
      title: "DevOps & Deployment",
      skills: [
        "AWS",
        "Apache",
        "Server Setup",
        "Deployment",
      ],
    },
    {
      icon: GitBranch,
      title: "Tools & Management",
      skills: [
        "Git",
        "GitHub",
        "Bitbucket",
        "VS Code",
        "Asana",
        "Trello",
        "Agile / Scrum",
      ],
    },
  ];

  return (
    <section
      id="skills"
      className="bg-slate-950 px-6 py-24"
    >
      <div className="mx-auto max-w-7xl">

        {/* Heading */}
        <div className="mb-14 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-blue-400">
            My Skills
          </p>

          <h2 className="mt-3 text-4xl font-bold text-white md:text-5xl">
            Technologies I Work With
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-slate-400">
            A broad technical skill set covering frontend,
            backend, CMS, e-commerce, databases and deployment.
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">

          {skillGroups.map((group) => {
            const Icon = group.icon;

            return (
              <div
                key={group.title}
                className="group rounded-2xl border border-white/10 bg-slate-900 p-7 transition duration-300 hover:-translate-y-1 hover:border-blue-500/40"
              >

                {/* Icon */}
                <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500/10 text-blue-400">
                  <Icon size={25} />
                </div>

                <h3 className="text-xl font-semibold text-white">
                  {group.title}
                </h3>

                {/* Skill Tags */}
                <div className="mt-5 flex flex-wrap gap-2">

                  {group.skills.map((skill) => (
                    <span
                      key={skill}
                      className="rounded-lg border border-white/10 bg-slate-950 px-3 py-1.5 text-sm text-slate-300 transition hover:border-blue-500/40 hover:text-white"
                    >
                      {skill}
                    </span>
                  ))}

                </div>

              </div>
            );
          })}

        </div>
      </div>
    </section>
  );
}

export default Skills;