import {
  Mail,
  Phone,
  MapPin,
  Send,
} from "lucide-react";

function Contact() {
  return (
    <section
      id="contact"
      className="bg-slate-950 px-6 py-24"
    >
      <div className="mx-auto max-w-6xl">

        {/* Heading */}
        <div className="mb-14 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-blue-400">
            Contact
          </p>

          <h2 className="mt-3 text-4xl font-bold text-white md:text-5xl">
            Let's Work Together
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-slate-400">
            Have a project, idea or opportunity? Feel free to
            get in touch.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">

          {/* Contact Information */}
          <div className="rounded-2xl border border-white/10 bg-slate-900 p-8">

            <h3 className="text-2xl font-semibold text-white">
              Get In Touch
            </h3>

            <p className="mt-4 leading-7 text-slate-400">
              I'm available for full-stack development,
              e-commerce, WordPress, Shopify and API development
              opportunities.
            </p>

            <div className="mt-8 space-y-6">

              <div className="flex items-center gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-500/10 text-blue-400">
                  <Mail size={20} />
                </div>

                <div>
                  <p className="text-sm text-slate-500">
                    Email
                  </p>

                  <a
                    href="mailto:bharatbhokre33@gmail.com"
                    className="text-white hover:text-blue-400"
                  >
                    bharatbhokre33@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-500/10 text-blue-400">
                  <Phone size={20} />
                </div>

                <div>
                  <p className="text-sm text-slate-500">
                    Phone
                  </p>

                  <a
                    href="tel:+919584503334"
                    className="text-white hover:text-blue-400"
                  >
                    +91 9584503334
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-500/10 text-blue-400">
                  <MapPin size={20} />
                </div>

                <div>
                  <p className="text-sm text-slate-500">
                    Location
                  </p>

                  <p className="text-white">
                    Indore, Madhya Pradesh, India
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Contact Form */}
          <form
            className="rounded-2xl border border-white/10 bg-slate-900 p-8"
            onSubmit={(e) => e.preventDefault()}
          >

            <div className="grid gap-5 sm:grid-cols-2">

              <div>
                <label className="mb-2 block text-sm text-slate-400">
                  Name
                </label>

                <input
                  type="text"
                  placeholder="Your name"
                  className="w-full rounded-lg border border-white/10 bg-slate-950 px-4 py-3 text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm text-slate-400">
                  Email
                </label>

                <input
                  type="email"
                  placeholder="your@email.com"
                  className="w-full rounded-lg border border-white/10 bg-slate-950 px-4 py-3 text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
                />
              </div>

            </div>

            <div className="mt-5">
              <label className="mb-2 block text-sm text-slate-400">
                Subject
              </label>

              <input
                type="text"
                placeholder="Project discussion"
                className="w-full rounded-lg border border-white/10 bg-slate-950 px-4 py-3 text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
              />
            </div>

            <div className="mt-5">
              <label className="mb-2 block text-sm text-slate-400">
                Message
              </label>

              <textarea
                rows="5"
                placeholder="Tell me about your project..."
                className="w-full resize-none rounded-lg border border-white/10 bg-slate-950 px-4 py-3 text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
              />
            </div>

            <button
              type="submit"
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-6 py-3 font-medium text-white transition hover:bg-blue-700"
            >
              Send Message
              <Send size={18} />
            </button>

          </form>
        </div>
      </div>
    </section>
  );
}

export default Contact;