import './App.css'
import { 
  Navbar, 
  Hero ,
  About,
  Skills,
  Experience,
  Projects,
  Services,
  Contact,
  Footer
} from './components'

function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Navbar />

      <main>
        <Hero />
        <About />
        <Skills />
        <Experience />
        <Projects />
         <Services />
        <Contact />
      </main>

       <Footer />
    </div>
  );
}

export default App