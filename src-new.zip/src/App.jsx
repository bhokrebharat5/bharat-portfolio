
import { 
  Navbar, 
  Hero ,
  About,
  Skills,
  Experience,
  Projects,
  Services,
  Contact,
  Footer
} from './components'
import useTheme from "./hooks/useTheme";

function App() {
  
  const [theme, setTheme] = useTheme();

  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--text)] transition-colors duration-300">
      
      <Navbar
        theme={theme}
        setTheme={setTheme}
      />

      <main>
        <Hero />
        <About />
        <Skills />
        <Experience />
        <Projects />
        <Services />
        <Contact />
      </main>

       <Footer />
    </div>
  );
}

export default App