import { useEffect, useState } from "react";

function useTheme() {
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem("bharat-portfolio-theme-mode") || "dark";
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("bharat-portfolio-theme-mode", theme);
  }, [theme]);

  return [theme, setTheme];
}

export default useTheme;