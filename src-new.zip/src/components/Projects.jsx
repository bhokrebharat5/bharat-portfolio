import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    number: "01",
    title: "MTX-Engines",
    category: "AI AGENT PLATFORM",
    description:
      "A multi-tenant platform for managing AI agents, tools, workflows and widgets with real-time streaming and visual workflow management.",
    technologies: [
      "React",
      "TypeScript",
      "Redux Toolkit",
      "RTK Query",
      "Vite",
      "Tailwind",
      "Supabase",
    ],
    featured: true,
  },
  {
    number: "02",
    title: "Fundly.ai",
    category: "FINTECH PLATFORM",
    description:
      "A healthcare embedded-finance platform with financial transaction pages, payment scheduling and a multi-vendor administration system.",
    technologies: [
      "React",
      "Node.js",
      "CodeIgniter",
      "MySQL",
    ],
  },
  {
    number: "03",
    title: "Space Jammit",
    category: "CLOUD STORAGE",
    description:
      "A secure cloud storage experience supporting deep folder structures, drag-and-drop operations and file management.",
    technologies: [
      "React.js",
      "Node.js",
    ],
  },
  {
    number: "04",
    title: "Real Profit",
    category: "SHOPIFY ANALYTICS",
    description:
      "Analytics application that calculates merchant profitability using shipping costs, payment fees and product costs.",
    technologies: [
      "Laravel",
      "MySQL",
      "React.js",
      "JavaScript",
    ],
  },
  {
    number: "05",
    title: "Oky",
    category: "HEALTH & MOBILE BACKEND",
    description:
      "High-performance backend services and predictive REST APIs based on historical customer data.",
    technologies: [
      "Node.js",
      "REST API",
    ],
  },
];

function Projects() {
  return (
    <section
      id="projects"
      className="border-t border-[var(--border)] px-5 py-28 md:px-8"
    >
      <div className="mx-auto max-w-7xl">

        {/* Header */}
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">

          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-blue-500">
              Selected Work
            </p>

            <h2 className="mt-5 max-w-3xl text-5xl font-bold leading-[0.95] tracking-[-0.04em] md:text-7xl">
              Projects that
              <br />
              <span className="text-[var(--text-muted)]">
                solve real problems.
              </span>
            </h2>
          </div>

          <p className="max-w-sm text-sm leading-7 text-[var(--text-secondary)]">
            A selection of products and platforms I've worked on
            across AI, fintech, e-commerce, cloud and healthcare.
          </p>

        </div>

        {/* Projects */}
        <div className="mt-20">

          {projects.map((project) => (
            <article
              key={project.number}
              className="group border-t border-[var(--border)] py-10 md:py-14"
            >

              <div className="grid gap-8 md:grid-cols-[80px_1fr_1.1fr_60px] md:items-start">

                {/* Number */}
                <div className="text-sm font-medium text-[var(--text-muted)]">
                  {project.number}
                </div>

                {/* Project title */}
                <div>
                  <p className="text-xs font-semibold tracking-[0.2em] text-blue-500">
                    {project.category}
                  </p>

                  <h3 className="mt-4 text-3xl font-bold tracking-tight transition-transform duration-300 group-hover:translate-x-2 md:text-5xl">
                    {project.title}
                  </h3>
                </div>

                {/* Description */}
                <div>

                  <p className="max-w-xl text-sm leading-7 text-[var(--text-secondary)] md:text-base">
                    {project.description}
                  </p>

                  <div className="mt-6 flex flex-wrap gap-2">
                    {project.technologies.map((technology) => (
                      <span
                        key={technology}
                        className="rounded-full border border-[var(--border)] px-3 py-1.5 text-xs text-[var(--text-muted)]"
                      >
                        {technology}
                      </span>
                    ))}
                  </div>

                </div>

                {/* Arrow */}
                <div className="hidden md:flex md:justify-end">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full border border-[var(--border)] transition-all duration-300 group-hover:border-blue-500 group-hover:bg-blue-500 group-hover:text-white">
                    <ArrowUpRight size={18} />
                  </div>
                </div>

              </div>

            </article>
          ))}

        </div>

        {/* Shopify highlight */}
        <div className="mt-10 border-t border-[var(--border)] pt-12">

          <div className="grid gap-8 md:grid-cols-2">

            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-blue-500">
                Shopify Applications
              </p>

              <h3 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">
                Building tools for
                <br />
                Shopify merchants.
              </h3>
            </div>

            <div className="flex flex-wrap content-start gap-3">
              {[
                "Persistent & Share Cart",
                "Preorder Automation",
                "Real Profit",
                "My Wishlist",
                "Volume & Tiered Pricing",
              ].map((app) => (
                <span
                  key={app}
                  className="rounded-full border border-[var(--border)] px-4 py-2.5 text-sm text-[var(--text-secondary)] transition hover:border-blue-500 hover:text-[var(--text)]"
                >
                  {app}
                </span>
              ))}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}

export default Projects;