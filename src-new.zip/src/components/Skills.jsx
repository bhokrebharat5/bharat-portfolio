
const skillGroups = [
  {
    number: "01",
    title: "Frontend",
    description:
      "Building modern, responsive and scalable user interfaces.",
    skills: [
      "React.js",
      "TypeScript",
      "JavaScript",
      "Redux Toolkit",
      "RTK Query",
      "Vite",
      "Tailwind CSS",
      "HTML5",
      "CSS3",
    ],
  },
  {
    number: "02",
    title: "Backend",
    description:
      "Designing APIs, backend services and application architecture.",
    skills: [
      "Node.js",
      "Express.js",
      "Laravel",
      "PHP",
      "REST APIs",
    ],
  },
  {
    number: "03",
    title: "E-commerce & CMS",
    description:
      "Creating custom commerce experiences and business platforms.",
    skills: [
      "Shopify",
      "Shopify Apps",
      "WordPress",
      "WooCommerce",
      "Custom Plugins",
      "Custom Themes",
    ],
  },
  {
    number: "04",
    title: "Database & Tools",
    description:
      "Working with data, version control and development infrastructure.",
    skills: [
      "MySQL",
      "MariaDB",
      "Git",
      "GitHub",
      "Redis",
      "AWS S3",
    ],
  },
];

function Skills() {
  return (
    <section
      id="skills"
      className="border-t border-[var(--border)] bg-[var(--surface)] px-5 py-28 transition-colors duration-300 md:px-8"
    >
      <div className="mx-auto max-w-7xl">

        {/* Header */}
        <div className="grid gap-8 md:grid-cols-[1fr_0.8fr]">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[var(--accent)]">
              Expertise
            </p>

            <h2 className="mt-5 text-5xl font-bold leading-[0.95] tracking-[-0.04em] md:text-7xl">
              Tools I use
              <br />
              <span className="text-[var(--text-muted)]">
                to build.
              </span>
            </h2>
          </div>

          <div className="flex items-end">
            <p className="max-w-lg text-sm leading-7 text-[var(--text-secondary)]">
              A decade of experience across frontend engineering,
              backend development, e-commerce, CMS platforms and
              modern web technologies.
            </p>
          </div>
        </div>

        {/* 2 × 2 Skills Grid */}
        <div className="mt-20 grid grid-cols-1 border-l border-t border-[var(--border)] sm:grid-cols-2">
          {skillGroups.map((group) => (
            <div
              key={group.number}
              className="
                group
                relative
                min-h-[320px]
                border-b
                border-r
                border-[var(--border)]
                p-7
                transition-colors
                duration-300
                hover:bg-[var(--background)]
                md:p-10
              "
            >
              {/* Top */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium tracking-[0.2em] text-[var(--text-muted)]">
                  {group.number}
                </span>

                <span
                  className="
                    text-lg
                    text-[var(--text-muted)]
                    transition-all
                    duration-300
                    group-hover:translate-x-1
                    group-hover:-translate-y-1
                    group-hover:text-[var(--accent)]
                  "
                >
                  ↗
                </span>
              </div>

              {/* Content */}
              <div className="mt-12">
                <h3
                  className="
                    text-3xl
                    font-bold
                    tracking-[-0.03em]
                    transition-transform
                    duration-300
                    group-hover:translate-x-1
                    md:text-4xl
                  "
                >
                  {group.title}
                </h3>

                <p className="mt-4 max-w-sm text-sm leading-6 text-[var(--text-secondary)]">
                  {group.description}
                </p>
              </div>

              {/* Skills */}
              <div className="mt-8 flex flex-wrap gap-2">
                {group.skills.map((skill) => (
                  <span
                    key={skill}
                    className="
                      rounded-full
                      border
                      border-[var(--border)]
                      bg-[var(--surface)]
                      px-3.5
                      py-1.5
                      text-xs
                      text-[var(--text-secondary)]
                      transition-all
                      duration-300
                      hover:-translate-y-0.5
                      hover:border-[var(--accent)]
                      hover:bg-[var(--accent-soft)]
                      hover:text-[var(--accent)]
                    "
                  >
                    {skill}
                  </span>
                ))}
              </div>

              {/* Bottom accent */}
              <div
                className="
                  absolute
                  bottom-0
                  left-0
                  h-px
                  w-0
                  bg-[var(--accent)]
                  transition-all
                  duration-500
                  group-hover:w-full
                "
              />
            </div>
          ))}
        </div>

        {/* Bottom Statement */}
        <div className="mt-12 flex flex-col gap-5 border-t border-[var(--border)] pt-8 md:flex-row md:items-center md:justify-between">
          <p className="max-w-2xl text-sm leading-7 text-[var(--text-muted)]">
            I focus on choosing the right technology for the
            problem rather than using technology for its own sake.
          </p>

          <div className="text-sm font-medium text-[var(--accent)]">
            React · Laravel · Wordpress · Shopify · Node
          </div>
        </div>

      </div>
    </section>
  );
}

export default Skills;