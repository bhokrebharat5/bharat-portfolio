function About() {
  return (
    <section
      id="about"
      className="border-t border-[var(--border)] px-5 py-28 md:px-8"
    >
      <div className="mx-auto max-w-7xl">

        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">

          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-blue-500">
              About Me
            </p>

            <p className="mt-8 text-sm leading-7 text-[var(--text-muted)]">
              Indore, India
            </p>
          </div>

          <div>

            <h2 className="text-4xl font-bold leading-tight tracking-[-0.03em] md:text-6xl">
              I turn complex ideas into
              <span className="text-[var(--text-muted)]">
                {" "}simple, scalable products.
              </span>
            </h2>

            <div className="mt-10 grid gap-6 md:grid-cols-2">

              <p className="text-base leading-8 text-[var(--text-secondary)]">
                With 10+ years of experience, I work across frontend,
                backend, CMS and e-commerce ecosystems to create
                reliable digital products.
              </p>

              <p className="text-base leading-8 text-[var(--text-secondary)]">
                My experience covers e-commerce, healthcare, fintech,
                fitness and modern SaaS applications, including
                complex APIs and third-party integrations.
              </p>

            </div>

            <div className="mt-12 grid grid-cols-3 border-y border-[var(--border)]">

              <div className="py-7">
                <p className="text-3xl font-bold">10+</p>
                <p className="mt-2 text-xs uppercase tracking-widest text-[var(--text-muted)]">
                  Years
                </p>
              </div>

              <div className="border-l border-[var(--border)] py-7 pl-5 md:pl-7">
                <p className="text-3xl font-bold">300+</p>
                <p className="mt-2 text-xs uppercase tracking-widest text-[var(--text-muted)]">
                  Projects
                </p>
              </div>

              <div className="border-l border-[var(--border)] py-7 pl-5 md:pl-7">
                <p className="text-3xl font-bold">5</p>
                <p className="mt-2 text-xs uppercase tracking-widest text-[var(--text-muted)]">
                  Shopify Apps
                </p>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}

export default About;