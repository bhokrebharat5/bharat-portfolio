import { ArrowUpRight } from "lucide-react";

const experiences = [
  {
    year: "2025 — Present",
    company: "WDT Technologies Pvt Ltd",
    role: "Sr. Full Stack Web Developer",
    description:
      "Developing a scalable AI agent management platform using React, TypeScript, Redux Toolkit and Vite. Working with multi-tenant architecture, SSE streaming and visual DAG workflows.",
    stack: [
      "React",
      "TypeScript",
      "Redux Toolkit",
      "Vite",
      "WordPress",
    ],
  },
  {
    year: "2022 — 2024",
    company: "Greychain Technology",
    role: "Sr. Full Stack Developer",
    description:
      "Led full-stack development for fintech platforms and high-performance mobile application backends, including scalable REST APIs and secure payment integrations.",
    stack: [
      "React",
      "Node.js",
      "REST API",
      "Laravel",
      "WordPress",
    ],
  },
  {
    year: "2022",
    company: "Clickspurr Technologies",
    role: "Sr. React Js Developer",
    description:
      "Developed and deployed dynamic web applications using React.js and Node.js while collaborating with design and product teams.",
    stack: [
      "React.js",
      "Node.js",
    ],
  },
  {
    year: "2015 — 2022",
    company: "Bitcot Technologies",
    role: "Software Engineer",
    description:
      "Worked across full-stack development, Shopify applications and WordPress/WooCommerce solutions. Developed and published five Shopify public applications.",
    stack: [
      "Laravel",
      "React",
      "Shopify",
      "WordPress",
      "MySQL",
    ],
  },
];

function Experience() {
  return (
    <section
      id="experience"
      className="border-t border-[var(--border)] bg-[var(--surface)] px-5 py-28 md:px-8"
    >
      <div className="mx-auto max-w-7xl">

        {/* Heading */}
        <div className="grid gap-8 md:grid-cols-2">

          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-blue-500">
              Experience
            </p>

            <h2 className="mt-5 text-5xl font-bold leading-[0.95] tracking-[-0.04em] md:text-7xl">
              A decade of
              <br />
              <span className="text-[var(--text-muted)]">
                building.
              </span>
            </h2>
          </div>

          <div className="flex items-end">
            <p className="max-w-md text-sm leading-7 text-[var(--text-secondary)]">
              From traditional web applications to modern AI
              platforms, my career has evolved alongside the web.
            </p>
          </div>

        </div>

        {/* Timeline */}
        <div className="mt-20">

          {experiences.map((experience) => (
            <div
              key={`${experience.company}-${experience.year}`}
              className="group grid gap-6 border-t border-[var(--border)] py-10 md:grid-cols-[180px_1fr_1.2fr_30px] md:gap-10 md:py-12"
            >

              {/* Year */}
              <div>
                <span className="text-sm text-[var(--text-muted)]">
                  {experience.year}
                </span>
              </div>

              {/* Company */}
              <div>
                <h3 className="text-xl font-bold md:text-2xl">
                  {experience.company}
                </h3>

                <p className="mt-2 text-sm text-blue-500">
                  {experience.role}
                </p>
              </div>

              {/* Description */}
              <div>

                <p className="text-sm leading-7 text-[var(--text-secondary)]">
                  {experience.description}
                </p>

                <div className="mt-5 flex flex-wrap gap-2">
                  {experience.stack.map((item) => (
                    <span
                      key={item}
                      className="rounded-full bg-[var(--surface-soft)] px-3 py-1.5 text-xs text-[var(--text-muted)]"
                    >
                      {item}
                    </span>
                  ))}
                </div>

              </div>

              <div className="hidden md:block">
                <ArrowUpRight
                  size={18}
                  className="text-[var(--text-muted)] transition group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-blue-500"
                />
              </div>

            </div>
          ))}

        </div>

      </div>
    </section>
  );
}

export default Experience;