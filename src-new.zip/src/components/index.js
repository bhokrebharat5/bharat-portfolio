import Hero from './Hero'
import Navbar from './navbar/Navbar';
import About from './About';
import Skills from './Skills';
import Experience from './Experience';
import Projects from './Projects';
import Services from './Services';
import Contact from './Contact';
import Footer from './footer/Footer';

export {
    Navbar,
    Hero,
    About,
    Skills,
    Experience,
    Projects,
    Services,
    Contact,
    Footer
}